# Decoder Razorpay backend (local test mode)

This Express backend serves the website and payment API from the same origin. It creates a ₹1,000 INR order on the server, returns only the public Razorpay Key ID to Checkout, verifies the checkout HMAC signature, fetches the payment from Razorpay, checks order ID/amount/currency, captures an authorized payment when needed, and grants the demo plan only when Razorpay reports `captured`.

## Important: open the site through this backend

**Do not open `index.html` using `file://` or Live Server on port 5500.** The payment button calls `/api/payment/order`; those addresses do not point at this Express server, which causes the common “Failed to fetch” / “Cannot reach payment API” error.

1. Install Node.js 18 or newer.
2. Open VS Code terminal in the `decoder-upgraded/backend` folder.
3. Run `npm install`.
4. Copy `.env.example` to a new file named `.env` in that same `backend` folder.
5. In Razorpay Dashboard, use **test mode** to copy your test Key ID and Key Secret into `.env`. Do not use live keys for local testing and never paste the secret into HTML, JavaScript, GitHub, or a public frontend.
6. Run `npm start` and keep the terminal open.
7. Open **http://localhost:3000** in Chrome, sign in to the demo profile, then open **Payments & Plans**.
8. Click **Check backend** first. It should report that the backend is online and whether the keys are configured. Then try checkout with Razorpay test payment details.

## Troubleshooting

- **“Cannot reach payment API” / `Failed to fetch`:** server isn't running, wrong port, or the page was opened via `file://`/Live Server. Use `http://localhost:3000`.
- **Backend online but keys missing:** `.env` must be in the `backend` directory, and the server must be restarted after editing it.
- **Order creation error:** check that the Key ID and Key Secret are matching test-mode credentials and inspect the terminal for the provider error.
- **Checkout script won't load:** check internet access, extensions/content blockers, or corporate network restrictions.
- **Payment authorized but not captured:** the backend attempts capture after validating the signature and order details. If Razorpay account settings prevent capture, inspect the Razorpay Dashboard before retrying.
- **Money deducted but UI shows an error:** do not pay a second time immediately. Check the Razorpay Dashboard for payment status and reconcile before retrying.

## Production requirements

This is a local demo integration, not a production commerce system. Orders are held in memory, demo login/progress is browser-local, and paid access is not linked to an authenticated database user. Before real payments, add authenticated accounts, persistent orders/payments/entitlements, webhook handling and replay protection, idempotency, refund/cancellation flows, rate limiting, HTTPS, audit logs, and server-side authorization for premium content. Test the complete flow in Razorpay test mode first.
