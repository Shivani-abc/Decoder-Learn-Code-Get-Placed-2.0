require('dotenv').config();
const express = require('express');
const path = require('path');
const crypto = require('crypto');
const Razorpay = require('razorpay');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const FRONTEND_DIR = path.resolve(__dirname, '..');
const AMOUNT_PAISE = 100000; // ₹1,000.00
const CURRENCY = 'INR';
const orders = new Map(); // Demo only; use a durable database for production.

app.use(express.json({ limit: '30kb' }));
app.use(express.static(FRONTEND_DIR));

function getRazorpay() {
  const key_id = process.env.RAZORPAY_KEY_ID;
  const key_secret = process.env.RAZORPAY_KEY_SECRET;
  if (!key_id || !key_secret) return null;
  return { client: new Razorpay({ key_id, key_secret }), key_id, key_secret };
}

app.get('/api/health', (_req, res) => {
  res.json({ ok: true, paymentConfigured: Boolean(process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET) });
});

app.post('/api/payment/order', async (req, res) => {
  const rp = getRazorpay();
  if (!rp) return res.status(503).json({ error: 'Razorpay is not configured. Copy .env.example to .env and add test keys.' });
  if (!req.body || req.body.plan !== 'pro') return res.status(400).json({ error: 'Unknown plan.' });
  try {
    const order = await rp.client.orders.create({
      amount: AMOUNT_PAISE,
      currency: CURRENCY,
      receipt: `decoder_${Date.now()}`,
      notes: { product: 'Decoder Pro' }
    });
    orders.set(order.id, { amount: AMOUNT_PAISE, currency: CURRENCY, createdAt: Date.now() });
    return res.json({ keyId: rp.key_id, orderId: order.id, amount: order.amount, currency: order.currency });
  } catch (err) {
    console.error('Razorpay order creation failed:', err.message);
    return res.status(502).json({ error: 'Could not create Razorpay order. Check server keys and Razorpay account status.' });
  }
});

app.post('/api/payment/verify', async (req, res) => {
  const rp = getRazorpay();
  if (!rp) return res.status(503).json({ verified: false, error: 'Razorpay is not configured.' });
  const { razorpay_order_id: orderId, razorpay_payment_id: paymentId, razorpay_signature: signature } = req.body || {};
  if (![orderId, paymentId, signature].every(v => typeof v === 'string' && v.length > 0)) {
    return res.status(400).json({ verified: false, error: 'Missing payment verification fields.' });
  }
  const order = orders.get(orderId);
  if (!order) return res.status(400).json({ verified: false, error: 'Order is unknown to this server session. Please restart checkout.' });
  const expected = crypto.createHmac('sha256', rp.key_secret).update(`${orderId}|${paymentId}`).digest('hex');
  const supplied = Buffer.from(signature, 'utf8');
  const expectedBuf = Buffer.from(expected, 'utf8');
  if (supplied.length !== expectedBuf.length || !crypto.timingSafeEqual(supplied, expectedBuf)) {
    return res.status(400).json({ verified: false, error: 'Invalid Razorpay signature.' });
  }
  try {
    let payment = await rp.client.payments.fetch(paymentId);
    if (payment.order_id !== orderId || payment.amount !== order.amount || payment.currency !== order.currency) {
      return res.status(400).json({ verified: false, error: 'Payment does not match this order. No paid access was granted.' });
    }
    // Razorpay may return an authorized payment when auto-capture is disabled.
    // Capture only after signature + order + amount checks have all passed.
    if (payment.status === 'authorized') {
      payment = await rp.client.payments.capture(paymentId, order.amount, order.currency);
    }
    if (payment.status !== 'captured') {
      return res.status(409).json({ verified: false, error: `Razorpay reports payment status “${payment.status}”. Paid access has not been granted. Check the Razorpay dashboard before retrying.` });
    }
    orders.delete(orderId);
    // Production must persist the verified entitlement to the authenticated user's database here.
    return res.json({ verified: true, paymentId, orderId, status: payment.status, plan: 'pro' });
  } catch (err) {
    console.error('Razorpay payment verification failed:', err.message);
    return res.status(502).json({ verified: false, error: 'Could not verify payment with Razorpay. Please contact support before retrying.' });
  }
});

app.listen(PORT, () => {
  console.log(`Decoder is running at http://localhost:${PORT}`);
  console.log(`Razorpay configured: ${Boolean(process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET)}`);
});
