const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const single = fs.readFileSync(path.join(root, 'decoder-single-file.html'), 'utf8');
const checks = [
  ['Internship panel is implemented', /V\.intern=function\(\).*?Internships & early-career roles/s.test(html)],
  ['Internship catalogue contains 20+ role paths', (html.match(/area:'(?:Software|AI & Data|Web|Cybersecurity|Cloud|Finance & Data|Design)'/g) || []).length >= 20],
  ['Internship search and filters are present', /dc-intern-search/.test(html) && /dc-intern-area/.test(html) && /dc-intern-mode/.test(html)],
  ['Application tracker status updates are present', /data-app-status/.test(html) && /LP\.applications/.test(html)],
  ['AI Coding Mentor route exists', /\['mentor','AI Coding Mentor'/.test(html)],
  ['Mock Interview Studio route exists', /V\.mockinterview=function/.test(html)],
  ['Progress Analytics route exists', /\['analytics','Progress Analytics'/.test(html)],
  ['Placement Command Centre route is available', /\['careerkit','Placement Command Centre'/.test(html) && /V\.careerkit=function/.test(html)],
  ['Resume-to-role keyword matcher exists', /ck-match-result/.test(html) && /Keyword overlap/.test(html)],
  ['Application Kanban and deadline calendar exist', /ck-app-form/.test(html) && /ck-deadline-form/.test(html) && /data-ck-app-status/.test(html)],
  ['Roadmaps and company directory exist', /ckRoadmaps/.test(html) && /ck-company-search/.test(html)],
  ['Aptitude mini-test and HR practice exist', /ck-aptitude-submit/.test(html) && /ck-hr-save/.test(html)],
  ['Referral tracker and saved job alerts exist', /ck-ref-form/.test(html) && /ck-alert-form/.test(html)],
  ['Admin summary and JSON export exist', /ck-export/.test(html) && /decoder-placement-data\.json/.test(html)],
  ['Single-file version matches main website', single === html],
  ['Offer comparison planner is present', html.includes('Offer comparison planner') && html.includes('ck-offer-form')],
  ['Weekly placement study planner is present', html.includes('Weekly placement study planner') && html.includes('plan-dsa')],
  ['Resume builder has structured sections and safe preview escaping', html.includes('rsummary') && html.includes('rprojecttitle') && html.includes('function escR') && html.includes('decoder_resume_draft')],
  ['Resume builder supports HTML export, print/PDF, and reset', html.includes('rdownload') && html.includes('window.print()') && html.includes('rreset')],
  ['Course library supports category and difficulty filters', html.includes('lp-course-category') && html.includes('LP.category===x') && html.includes('Advanced')],
  ['Placement drive tracking persists between page visits', html.includes("decoder_v2_tracked_drives") && html.includes("JSON.stringify(DA)")],
  ['Project portfolio tracker route and local persistence exist', html.includes("V.portfolio=function") && html.includes("decoder_portfolio_projects") && html.includes('dx-project-form')],
  ['Portfolio supports project removal and JSON export', html.includes('data-dx-project-remove') && html.includes('decoder-project-portfolio.json')],
  ['Technical interview deck has topic-based question bank', html.includes('V.techdeck=function') && html.includes('dxQuestions') && html.includes('dx-next-question')],
  ['Technical interview notes can be saved and exported', html.includes('decoder_tech_interview_notes') && html.includes('decoder-interview-notes.json')]
];
let failed = 0;
for (const [name, ok] of checks) {
  console.log(`${ok ? 'PASS' : 'FAIL'} ${name}`);
  if (!ok) failed++;
}
if (failed) process.exit(1);
console.log(`\n${checks.length}/${checks.length} smoke checks passed.`);

